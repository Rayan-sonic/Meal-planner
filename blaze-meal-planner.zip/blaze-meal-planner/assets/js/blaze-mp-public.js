/**
 * etp-mp-public.js
 *
 * Custom JS to run on frontend. Used for
 * saving workouts, misc meal planner actions.
 *
 * @author Expanded Fronts, LLC
 * @link   https://expandedfronts.com
 */

/**
 * Main function for loading recipes.
 */
 jQuery( 'body' ).on( 'thickbox:iframe:loaded', function ( event ) {
 	console.log('thickbox open');
 	jQuery(".avg-rating").rating({
 		theme: 'krajee-fas',
 		filledStar: '<i class="fas fa-star" style="color:#ff5b02"></i>',
 		emptyStar: '<i class="far fa-star"></i>',
 		showCaption: false,
 		step: 0.5,
 		displayOnly: true,
 	});
 });
 function cus_call_r(link){
	var parentClass = link.parentNode.className;
	// Your code here
	console.log('Parent class:', parentClass);
	var parent = link.parentNode;
	var parentClassToRemove = 'drop-feedback';

	parent.classList.remove(parentClassToRemove);
	// alert(parentClass);
	jQuery(this).parent().removeClass('drop-feedback');
	// jQuery(this).parent.html('');
	jQuery(parent).html('');
	
	if(((jQuery(parent).attr('id'))%2)==0){
		jQuery(parent).html('<div class="meal-snacks"><p>Snack</p></div>');
	} else{
		jQuery(parent).html('<div class="meal-snacks"><p>Meal</p></div>');
	}
	calculate_day_totals();
}
function this_add_meal_r(link){
	// alert();
	etp_add_box();
}

jQuery(window).load(function () {
	jQuery('.blaze-category').on('click', function(e){
		//alert('showsssss');
		e.preventDefault();
		jQuery('.blaze-category').removeClass('active');
		jQuery(this).addClass('active');
		var url = jQuery(this).attr('href');
		var paged = url.split('&paged=');
		var tag = '';
		var category = jQuery(this).text();
		//alert(category);
		jQuery( '#grid' ).html('<div id="loading" class="spinner-loader"><div class="load-wrap"><span>Loading, Please wait...</span></div></div>');
		jQuery( '#grid #loading' ).css('display','block');
	etp_get_recipes(paged[1], tag, category); //Load Posts (feed in paged value)

});
});



function mini_my_dmeal(link){
		dropArea = document.getElementById( 'drop-area' );
		classie.remove( dropArea, 'show' );
}
// jQuery( '#blaze-add-box' ).on('click', function(e) {
// 	e.preventDefault();
// 	etp_add_box();
// });
 function etp_get_recipes( paged='0', tag, category ) {
 	var paged_value = paged;
 	var recipe_tag = tag;
 	var recipe_cat = category;

	//alert(paged_value);

 	jQuery.ajax({
 		type: 'POST',
 		url: ajaxurl,
 		data: {
 			action: 'etp_get_recipes',
 			paged: paged_value,
 			tag: recipe_tag,
 			category: recipe_cat,
 		},
 		success: function( response ) {
			//alert(response);
			//alert('swdwd');
 			jQuery( '#grid' ).html( response );
 			
 			jQuery(".input-rating").rating({
 				theme: 'krajee-fas',
 				filledStar: '<i class="fas fa-star" style="color:#ff5b02"></i>',
 				emptyStar: '<i class="far fa-star"></i>',
 				showCaption: false,
 				step: 0.5,
 			}).on("rating:change", function(event, value, caption) {
 				var recipe_id = jQuery(this).attr('data-recipe_id');
 				var rating = value;
 				
 				jQuery.ajax({
 					type: 'POST',
 					url: ajaxurl,
 					data: {
 						action: 'etp_recipe_rating',
 						recipe_id: recipe_id,
 						rating: rating,
 					},
 					dataType: 'json',
 					success: function( result ) {
 						var avg_rate = JSON.parse(result);
 						if(avg_rate){
 							//jQuery('#avg_'+recipe_id).html((Math.round( avg_rate * 10 ) / 10));
 							jQuery('#avg_'+recipe_id).html(parseFloat(avg_rate).toFixed(1));
 						}
 					}
 				}).fail( function(response) {
 					if ( window.console && window.console.log ) {
 						console.log( response );
 					}
 				});

 			});
 			jQuery("html, body").animate({ scrollTop: 0 }, "fast");
 			init();
 		},
 		/*beforeSend: function () { 			
 			jQuery( '#grid' ).html('<div id="loading" class="spinner-loader"><div class="load-wrap"><span>Loading, Please wait...</span></div></div>');
 			jQuery( '#grid #loading' ).css('display','block');
 		},*/
 		complete: function () {
 			jQuery( '#grid #loading' ).css('display','none');
 			jQuery( '#loading' ).remove();
 		}
 	}).fail( function(response) {
 		if ( window.console && window.console.log ) {
 			console.log( response );
 		}
 	});

 }

 
//--------------------------------------------------//
jQuery(window).on('load', function() {
	jQuery(".page-numbers").attr("href", "#");
	jQuery('.etp-mp-pagination .page-numbers').on('click', function(e) {
		e.preventDefault(); // Prevent the default behavior of the link
		  //alert();
		  var inkal = jQuery(this).text();
		  etp_get_recipes(paged=inkal)
	  });
   });
   jQuery(".page-numbers").attr("href", "#");
   jQuery('.etp-mp-pagination .page-numbers').on('click', function(e) {
	   e.preventDefault(); // Prevent the default behavior of the link
		// alert();
		 var inkal = jQuery(this).text();
		 etp_get_recipes(paged=inkal)
	 });
//jQuery(document).ready(function() {
	
// });
//  jQuery(document).ready(function() {
	// jQuery('.etp-mp-pagination .page-numbers').on('click', function(e) {
	//   e.preventDefault(); // Prevent the default behavior of the link
	// 	alert();
	//   var linkValue = jQuery(this).data('value'); // Retrieve the value using the data attribute
	//   alert('Link value: ' + linkValue);
	// });
//   });
//--------------------------------------------------//
/**
 * Adds a new day.
 */
 function blaze_add_day() {

 	var next_day 	= jQuery( '#blaze-next-day' ).val();
 	var current_day = jQuery( '#blaze-current-day' ).val();
 	var day_name = '';
 	switch(next_day) {
 		case '1':
 		day_name = 'Mon';
 		break;
 		case '2':
 		day_name = 'Tues';
 		break;
 		case '3':
 		day_name = 'Wed';
 		break;
 		case '4':
 		day_name = 'Thurs';
 		break;
 		case '5':
 		day_name = 'Fri';
 		break;
 		case '6':
 		day_name = 'Sat';
 		break;
 		case '7':
 		day_name = 'Sun';
 		break;
 		default:
 		day_name = next_day;

 	}
 	
 	if ( next_day <= 7 ) {
 		etp_save_day();
 		clear_etp_drop_areas();
 		jQuery( '.blaze-day-nav li a.active' ).removeClass('active');
 		jQuery( '.blaze-day-nav li:last' ).before('<li><a class="blaze-day-'+next_day+' active" onclick="blaze_load_day('+next_day+')">'+day_name+'</a></li>');
 		jQuery( '#blaze-current-day' ).val(next_day);
 		next_day++;
 		jQuery( '#blaze-next-day' ).val( next_day );

		// Recalculate totals.
		calculate_day_totals();
	} if ( next_day == 8 ) {
		jQuery('.next').parents('li').remove();
	}
}

/**
 * Adds a new box.
 */
 function etp_add_box() {
 	count = jQuery('.blaze-drop-area').length;
 	
 	count++;
 	if(count%2==0){
 		var box_center_text = '<div class="meal-snacks"><p>Snack</p></div>';
 	} else {
 		var box_center_text = '<div class="meal-snacks"><p>Meal</p></div>';
 	}
 	jQuery( '#blaze-add-box' ).before( '<div id="'+count+'" class="drop-area__item blaze-drop-area blaze-display-box">'+box_center_text+'</div>' );
 	jQuery('#blaze-box-container').animate({scrollLeft: 99999}, 250);
 	init();
 }

/**
 * Loads the given day's worth of meals.
 */
 function blaze_load_day( day ) {
	// Grab the data.
	var data 		= jQuery('#data-store').data();
	var day_meals 	= data[day];
	var leftover_data 		= jQuery('#leftover-store').data();
	var day_leftover 	= leftover_data[day];
	
	// Save the current day and clear the drop areas.
	etp_save_day();
	clear_etp_drop_areas();

	current_day = day;

	// Set vals so we can save, etc.
	jQuery( '#blaze-current-day' ).val( current_day );

	// Get the data.
	etp_get_html( day_meals,day_leftover );

	// Set the active class.
	jQuery( '.blaze-day-nav li a.active' ).removeClass('active');
	jQuery( '.blaze-day-'+current_day ).addClass('active');

}

/**
 * Saves the current day in memory.
 */
 function etp_save_day() {
 	var day_id 			= jQuery( '#blaze-current-day' ).val();
 	var day_data		= jQuery( '#data-store' ).data();
 	var leftover_data = jQuery( '#leftover-store' ).data();
 	var input_values 	= {};
 	var unique_recipes = [];
 	var leftover_values = {};
 	jQuery( '#drop-area input.blaze-recipe-id' ).each( function() {
 		
 		var id = jQuery(this).parent().attr('id');
 		input_values[id] = jQuery(this).val();
 		leftover_values[jQuery(this).val()] = [];
 	});

 	day_data[day_id] = input_values; 	

 	jQuery( '#data-store' ).data( day_data );
 	
 	jQuery( '#drop-area input[type=checkbox]' ).each( function() {
 		var id = jQuery(this).parents('.etp-macro-leftover').parents('.blaze-info-wrap').parents('.blaze-drop-area').attr('id');
 		var receipe_id = jQuery(this).parents('.blaze-drop-area').find('.blaze-recipe-id').val();
 		
 		leftover_values[receipe_id][id] = [];
 		if(this.checked){
 			leftover_values[receipe_id][id] = 1;
 		} else {
 			leftover_values[receipe_id][id] = 0;
 		}
 		
 	});
 	
 	leftover_data[day_id] = leftover_values;
 	
 	jQuery( '#leftover-store' ).data( leftover_data );
 }

/**
 * Calculates the total macros for the day.
 */
 function calculate_day_totals() {
 	var carb_total 		= 0;
 	var calorie_total 	= 0;
 	var fat_total 		= 0;
 	var protein_total 	= 0;
 	var net_carbs_total 	= 0;

 	jQuery( '#drop-area input.etp-macro-input').each( function() {

 		if ( jQuery(this).hasClass( 'etp-calories' ) ) {
 			calorie_total += parseInt( jQuery(this).val() );
 		}

 		if ( jQuery(this).hasClass( 'etp-carbs' ) ) {
 			carb_total += parseInt( jQuery(this).val() );
 		}

 		if ( jQuery(this).hasClass( 'etp-fat' ) ) {
 			fat_total += parseInt( jQuery(this).val() );
 		}

 		if ( jQuery(this).hasClass( 'etp-protein' ) ) {
 			protein_total += parseInt( jQuery(this).val() );
 		}

 		if ( jQuery(this).hasClass( 'etp-net_carbs' ) ) {
 			net_carbs_total += parseInt( jQuery(this).val() );
 		}
 	});
 	
 	jQuery( '#blaze-cal-total' ).html( calorie_total );
 	jQuery( '#blaze-carbs-total' ).html( carb_total );
 	jQuery( '#blaze-fat-total' ).html( fat_total );
 	jQuery( '#blaze-protein-total' ).html( protein_total );
 	jQuery( '#blaze-net-carbs-total' ).html( net_carbs_total );
 }

/**
 * Clears the drop areas.
 */
 function clear_etp_drop_areas() {
 	var i = 1;
 	jQuery( '.blaze-drop-area' ).each( function() {
 		jQuery(this).html('');
 		jQuery(this).removeClass('drop-feedback');
 		if((i%2)==0){
 			jQuery(this).html('<div class="meal-snacks"><p>Snack</p></div>');
 		} else{
 			jQuery(this).html('<div class="meal-snacks"><p>Meal</p></div>');
 		}
 		i++;
 	});

	// Recalculate day totals to reset to 0
	calculate_day_totals();
}

/**
 * Returns the HTML for a previously saved day.
 */
 function etp_get_html( meals,leftover ) {
 	
 	jQuery.ajax({

 		type: 'POST',
 		url: ajaxurl,
 		data: {
 			action: 'etp_get_html',
 			meals: meals,
 			leftover: leftover,
 		},
 		dataType: 'json',
 		success: function( response ) {
 			jQuery.each( response, function( key, value ) {
 				day_element = jQuery( '#' + key );
 				
 				if ( ! day_element.length ) {
 					
 					//jQuery( '#blaze-add-box' ).before( '<div id="'+key+'" class="drop-area__item blaze-drop-area blaze-display-box">'+value+'</div>' );
 					jQuery( '#' + key ).html( value );
 				} else {
 					
 					jQuery( '#' + key ).html( value );
 					
 				}

 			});

 			calculate_day_totals();
 		}

 	}).fail( function(response) {
 		console.log(response);
 	});
 }

/**
 * Saves the entire plan via AJAX
 */
 function etp_save_plan( plan_id ) {

 	title = jQuery( '#etp-plan-name').val();
 	tb_remove();

	// Save the current day (it may not have been already)
	etp_save_day();
	var recipe_data = jQuery( '#data-store' ).data();
	var leftover_data = jQuery( '#leftover-store' ).data();
	 
	const inputText = jQuery('#blaze-count-p').text();
	const lines = inputText.trim().split('\n');
	const nutrientValues = {};

	for (const line of lines) {
	const [key, value] = line.split(':');
	nutrientValues[key.trim()] = parseFloat(value.trim());
	}

	var nutrientValuess = nutrientValues;
	//alert(nutrientValuess);
	console.log(nutrientValuess);
	
	
	if ( typeof plan_id != 'undefined' ) {
		save_type = jQuery( '#etp-save-type').val();
		data = {
			action: 'etp_save_plan',
			recipes: recipe_data,
			leftover: leftover_data,
			title: 	title,
			plan_id: plan_id,
			save_type: save_type,
			nutrient_val: nutrientValuess
		}
	} else {
		data = {
			action: 'etp_save_plan',
			recipes: recipe_data,
			leftover: leftover_data,
			title: 	title,
			nutrient_val: nutrientValuess
		}
	}

	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: data,
		dataType: 'json',
		success: function( response ) {
			
			if ( response != 'false' ) {
				window.location = etp_vars.home_url + '/plan-details/?plan=' + response;
			} else {
				alert( 'There was an error saving the plan. Please try again.' );
			}

		}
	}).fail( function(response) {
		if ( window.console && window.console.log ) {
			console.log( response );
		}
	});
}

function etp_delete_plan( plan_id ) {
	tb_remove();

	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: {
			action: 'etp_delete_plan',
			plan_id: plan_id
		},
		dataType: 'json',
		success: function( response ) {
			if ( response == 'true' ) {
				jQuery( '#etp-plan-wrap-'+plan_id).fadeOut(100, function() { jQuery(this).remove();});
				//jQuery( '#etp-plan-wrap-'+plan_id ).remove();
			}
		}
	}).fail( function(response) {
		if ( window.console && window.console.log ) {
			console.log( response );
		}
	});
}

function etp_load_plan() {
	plan_id = jQuery( '#blaze-plan-id' ).val();

	if ( plan_id != 0 ) {
		jQuery.ajax({
			type: 'POST',
			url: ajaxurl,
			data: {
				action: 'etp_get_plan_data',
				plan_id: plan_id
			},
			dataType: 'json',
			success: function( response ) {
				
				dropArea 	= document.getElementById( 'drop-area' ),
				classie.add(dropArea, 'show');
				jQuery( '#data-store' ).data( response.meals );
				jQuery( '#leftover-store' ).data( response.leftover );
				
				blaze_load_day( 1 );
				jQuery( '#blaze-plan-id' ).val(0);
			}
		}).fail( function(response) {
			if ( window.console && window.console.log ) {
				console.log( response );
			}
		});

	}


}

//If pagination is clicked, load correct posts
jQuery('.page-numbers').on('click', function(e){
	e.preventDefault();
	jQuery( '#grid' ).html('<div id="loading" class="spinner-loader"><div class="load-wrap"><span>Loading, Please wait...</span></div></div>');
	jQuery( '#grid #loading' ).css('display','block');
	var url 		= jQuery(this).attr('href');
	var paged 		= url.split('&paged=');
	var tagged 		= jQuery( '#etp-current-tag' ).val();
	var categorized = jQuery( '#etp-current-cat' ).val();

	etp_get_recipes(paged[1], tagged, categorized ); //Load Posts (feed in paged value)
});

jQuery('.etp-tag').on('click', function(e){
	e.preventDefault();

	var url = jQuery(this).attr('href');
	var paged = url.split('&paged=');
	var tag = jQuery(this).html();
	jQuery( '#grid' ).html('<div id="loading" class="spinner-loader"><div class="load-wrap"><span>Loading, Please wait...</span></div></div>');
	jQuery( '#grid #loading' ).css('display','block');
	etp_get_recipes(paged[1], tag); //Load Posts (feed in paged value)

});

//jQuery('.etp-category').on('click', function(e){
	jQuery('.blaze-category').on('click', function(e){
		e.preventDefault();
		jQuery('.blaze-category').removeClass('active');
		jQuery(this).addClass('active');
		var url = jQuery(this).attr('href');
		var paged = url.split('&paged=');
		var tag = '';
		var category = jQuery(this).html();
		jQuery( '#grid' ).html('<div id="loading" class="spinner-loader"><div class="load-wrap"><span>Loading, Please wait...</span></div></div>');
		jQuery( '#grid #loading' ).css('display','block');
	etp_get_recipes(paged[1], tag, category); //Load Posts (feed in paged value)

});

	jQuery(function(){
	// Allows searching by recipe tag.
	var recipe_search = jQuery( '#blaze-recipe-search' );

	recipe_search.keyup(function(ev) {

		ev.preventDefault();

		if ( ev.keyCode === 13 ) {
			jQuery( '#grid' ).html('<div id="loading" class="spinner-loader"><div class="load-wrap"><span>Loading, Please wait...</span></div></div>');
			jQuery( '#grid #loading' ).css('display','block');
			etp_get_recipes(0, recipe_search.val() );
		}

	});
});
	jQuery('.remove-tags').on('click', function(e){
		e.preventDefault();

		var url = jQuery(this).attr('href');
		var paged = url.split('&paged=');
		jQuery( '#grid' ).html('<div id="loading" class="spinner-loader"><div class="load-wrap"><span>Loading, Please wait...</span></div></div>');
		jQuery( '#grid #loading' ).css('display','block');
		etp_get_recipes(paged[1]); //Load Posts (feed in paged value)

	});

// Allow users to uncheck items that shouldn't be printed.
jQuery(document).on( 'click', '.etp-ingredient-cb' ,function(e) {

	if ( ! jQuery(this).parent().hasClass( 'no-print' ) ) {
		jQuery(this).parent().addClass('no-print');		
		jQuery(this).parent().removeClass('print');		
	} else {
		jQuery(this).parent().removeClass( 'no-print' );
		jQuery(this).parent().addClass('print');		
		
	}
	var count = jQuery(this).parents('.cat_group').find('.etp-shopping-list').children('li:not(.no-print)').length;
//	console.log(count);
if(count==0){
	if ( ! jQuery(this).parents('.cat_group').find('h3.cat_name').hasClass( 'no-print' ) ) 
		jQuery(this).parents('.cat_group').find('h3.cat_name').addClass('no-print');
} else {
	jQuery(this).parents('.cat_group').find('h3.cat_name').removeClass('no-print');
}

});

// Allows removing a single meal/recipe from the drop zone.
jQuery( '.blaze-remove-meal' ).on('click', function(e){
	e.preventDefault();
	jQuery(this).parent().removeClass('drop-feedback');
	jQuery(this).parent().html('');
	
	if(((jQuery(this).parent().attr('id'))%2)==0){
		jQuery(this).parent().html('<div class="meal-snacks"><p>Snack</p></div>');
	} else{
		jQuery(this).parent().html('<div class="meal-snacks"><p>Meal</p></div>');
	}
	calculate_day_totals();
});

jQuery( '#blaze-add-box' ).on('click', function(e) {
	e.preventDefault();
	etp_add_box();
});

jQuery( '#blaze-minimize-button' ).on('click', function(e) {
	dropArea = document.getElementById( 'drop-area' );
	classie.remove( dropArea, 'show' );
});

function init() {

	var body = document.body,
	dropArea = document.getElementById( 'drop-area' ),
	droppableArr = [], dropAreaTimeout;

	etp_load_plan();

	// initialize droppables
	[].slice.call( document.querySelectorAll( '#drop-area .blaze-drop-area' )).forEach( function( el ) {
		droppableArr.push( new Droppable( el, {
			onDrop : function( instance, draggableEl ) {
				// show checkmark inside the droppabe element
				classie.add( instance.el, 'drop-feedback' );
				//console.log( draggableEl );
				//console.log(instance.el);
				temp = jQuery( draggableEl ).html();
				jQuery(temp).find('.etp-macro-info').remove();
				jQuery( instance.el ).html( temp );
				jQuery( instance.el ).find( '.etp-macro-info' ).remove();
				jQuery( instance.el ).find( '.etp-recipe-tags' ).remove();
				jQuery( instance.el ).find( '.etp-macro-avg-rating' ).remove();
				jQuery( instance.el ).find( '.recipe_rating' ).remove();
				jQuery( instance.el ).find( '.etp-macro-net-carbs' ).remove();				
				jQuery( instance.el ).find( '.blaze-hidden' ).removeClass('blaze-hidden' );
				jQuery( instance.el ).find( '.blaze-info-wrap' ).addClass( 'dropped-info' );
				jQuery( instance.el ).find('.dropped-info').append('<div class="etp-macro-leftover"><input type="checkbox" value="1" name="leftover" class="leftover_chkbox"  /> <label class="leftover_label">Leftover</label></div>');
				calculate_day_totals();
			}
		} ) );
	} );

	// initialize draggable(s)
	[].slice.call(document.querySelectorAll( '#grid .grid__item' )).forEach( function( el ) {
		new Draggable( el, droppableArr, {
			draggabilly : { containment: document.body },
			onStart : function() {
				// add class 'drag-active' to body
				classie.add( body, 'drag-active' );
				// clear timeout: dropAreaTimeout (toggle drop area)
				clearTimeout( dropAreaTimeout );
				// show dropArea
				classie.add( dropArea, 'show' );
			},
			onEnd : function( wasDropped ) {
				var afterDropFn = function() {
					// hide dropArea
					//classie.remove( dropArea, 'show' );
					//remove class 'drag-active' from body
					classie.remove( body, 'drag-active' );
				};

				if( !wasDropped ) {
					afterDropFn();
				}
				else {
					// after some time hide drop area and remove class 'drag-active' from body
					clearTimeout( dropAreaTimeout );
					dropAreaTimeout = setTimeout( afterDropFn, 1 );
				}
			}
		} );
	} );
}

function toggle(source) {
	
	checkboxes = document.getElementsByName('selectall');
	for(var i=0, n=checkboxes.length;i<n;i++) {
		checkboxes[i].checked = source.checked;
	}
	if (checkboxes.checked = source.checked) {
		jQuery('.cat_group h3.cat_name').removeClass('no-print');
		jQuery( "#slet" ).addClass('Allcrl');
	} else {
		jQuery('.cat_group h3.cat_name').addClass('no-print');
		jQuery( "#slet" ).removeClass('Allcrl');
	}

}
jQuery(document).ready(function(){
	jQuery(".avg-rating").rating({
		theme: 'krajee-fas',
		filledStar: '<i class="fas fa-star" style="color:#ff5b02"></i>',
		emptyStar: '<i class="far fa-star"></i>',
		showCaption: false,
		step: 0.5,
		displayOnly: true,
	});
	
})
jQuery(document).ajaxSuccess(function() {
	jQuery(".avg-rating").rating({
		theme: 'krajee-fas',
		filledStar: '<i class="fas fa-star" style="color:#ff5b02"></i>',
		emptyStar: '<i class="far fa-star"></i>',
		showCaption: false,
		step: 0.5,
		displayOnly: true,
	});
});