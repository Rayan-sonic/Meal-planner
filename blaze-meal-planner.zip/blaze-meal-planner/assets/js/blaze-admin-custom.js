jQuery(document).ready(function($){
    var carbs=$("#recipe_carbs");
    var fiber=$("#recipe_fiber");
    carbs.keyup(function(){
        var net_carbs=isNaN(parseInt( carbs.val() )-parseInt( fiber.val() )) ? 0 :(parseInt( carbs.val() )-parseInt( fiber.val() ))
        $("#recipe_net_carbs").val(net_carbs);
    });
    fiber.keyup(function(){
        var net_carbs=isNaN(parseInt( carbs.val() )-parseInt( fiber.val() )) ? 0 :(parseInt( carbs.val() )-parseInt( fiber.val() ))
        $("#recipe_net_carbs").val(net_carbs);
    });
});